<?php
class Register_model extends CI_Model
{
    
    public function insertCommon($data = array(),$table = "")
    {
        return $this->db->insert($table,$data);
    }

    public function select($where = array(), $table = "")
    {
        if($where != null){
            $this->db->select('*');
            $this->db->from($table);
            $this->db->where($where);
            $res = $this->db->get();
        }else{
            $this->db->select('*');
            $this->db->from($table);
            $res = $this->db->get();
        }
        return $res->result_array();
    }
    public function checkUser($data){
        $st=$this->db->SELECT('*')->from('users')
                        ->WHERE('email',$data['email'])
                        ->WHERE('password',$data['password'])
                        ->get()->result_array();
        if(count($st)>0)
        {
            return $st[0];
        }
        else
        {
            return false;
        }
    }

    // function insert($data)
	// {
	// 	$this->db->insert('users', $data);
	// }
    public function update($data = array(), $table = "" , $where = array()){
        $this->db->where($where);
        $this->db->update($table,$data);
    }
    public function delete($table = "" , $where = array()){
        $this->db->where($where);
        $this->db->delete($table);
    }
    
}

?>