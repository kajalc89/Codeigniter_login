<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	public function __construct() { 

		parent::__construct();
        $this->load->model('register_model');
	}

	public function index()
	{
		$this->load->view('resgiter_view');
	}
    public function add_record()
	{
		$post = $this->input->post();
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('name', 'Name', 'required|trim|min_length[5]|max_length[40]');
		$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
        $this->form_validation->set_rules('mobile', 'Mobile Number ', 'required|trim|min_length[10]|max_length[10]');
		$this->form_validation->set_rules('password', 'Password ', 'required');
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		if($this->form_validation->run() == TRUE && $post){
			$data = array(
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email'),
				'mobile' => $this->input->post('mobile'),
				'password' => $this->input->post('password')
			);

			$insert = $this->register_model->insertCommon($data,'users');
			$this->session->set_flashdata('success', 'User added successfully.');
			 redirect('login');
			
		    }else{
				$this->load->view('resgiter_view');

			}	
	}

}
