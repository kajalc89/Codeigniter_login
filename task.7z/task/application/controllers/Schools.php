<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Schools extends CI_Controller {

    public function __construct() { 

		parent::__construct();
        $this->load->model('register_model');
	}

	public function index()
	{
		$data['schoolsData'] = $this->register_model->select(array(),'school_details');
		// echo '<pre>';print_r($data);die;
		$this->load->view('schools_view',$data);
	}
	
    public function create()
	{
		$post = $this->input->post();
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('location', 'Location', 'required');
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		if($this->form_validation->run() == TRUE && $post){
			$data = array(
				'name' => $this->input->post('name'),
				'location' => $this->input->post('location'),
			);

			$insert = $this->register_model->insertCommon($data,'school_details');
			$this->session->set_flashdata('success', 'User added successfully.');
			 redirect('Schools');
			
		    }else{
				//$data['countries'] = $this->register_model->select(array('country_id'),'tbl_country');
				$this->load->view('add_schools');

			}	
	}
    public function delete($id = ""){
        $this->register_model->delete('school_details',array('id'=>$id));
        $this->session->set_flashdata('success', 'Information has been delete successfully...');
        redirect('Schools');
    }

    public function edit($id = ""){
        
        $post = $this->input->post();
        if($id =="" && $post){
            $data = array('name'=>$post['name'],'location'=>$post['location']);
            $this->register_model->update($data,'school_details',array('id'=>$post['id']));
            $this->session->set_flashdata('success', 'User updated successfully...!');
            redirect('Schools');
        }else{
			// $data['countries'] = $this->user_model->select(array('country_id'),'tbl_country');
             $data['info'] = $this->register_model->select(array('id'=>$id),'school_details');
           //echo '<pre>'; print_r($data);
            $this->load->view('edit_school',$data);
        }
    }
}
