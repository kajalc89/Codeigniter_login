<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    public function __construct() { 

		parent::__construct();
        $this->load->model('register_model');
    
	}

    public function index()
	{
		$this->load->view('login_view');
	}

    public function get_user(){  
        if($_POST){
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
		$this->form_validation->set_rules('password', 'Password ', 'required');
        if ($this->form_validation->run() == FALSE) {

            $data['error'] = validation_errors();
            $this->load->view('login_view');
            }
            else {
                // if validation passes, check for user credentials from database
                $user = $this->register_model->checkUser($_POST);
                if ($user) {
                // if an record of user is returned from model, save it in session and send user to dashboard
                    //$this->session->set_userdata($user);
                    $this->session->set_flashdata('success','Login');

                     redirect(base_url().'Schools');
                } else {
                // if nothing returns from model , show an error
                    $data['error'] = 'Sorry! The credentials you have provided are not correct';
                    $this->load->view('login_view',$data);
                }
            }
         
        }  

    }
public function logout(){
    $this->session->sess_destroy();
    redirect('login');
}
}