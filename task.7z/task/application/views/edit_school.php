<?php $this->load->view('header');?>
<div class="row">
<div class="col-md-4">
</div>
<div class="col-md-4 pt-2">
    <div class="card">
        <div class="card-body">
  
        <?php if($this->session->flashdata('success')){ ?>        
            <div class="alert alert-success text-center" role="alert">
                <?=$this->session->flashdata('success');?>
            </div>
        <?php }  ?>

        <div class="text-center">
        <h3 class="text-primary">Add Details</h3>
        </div>
            <form action="<?php echo base_url();?>schools/edit" method="POST">
                <div class="form-group">
                    <label for="exampleInputEmail1"><strong>Name</strong></label>
                    <input class="input--style-4" type="hidden" name="id" value="<?php echo $info[0]['id'];?>">
                    <input type="text" class="form-control" name="name" value="<?php echo $info[0]['name'];?>">
                    <small class="form-text text-danger"><?php echo form_error('name');?></small>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1"><strong>Location</strong></label>
                    <input type="text" class="form-control"  name="location" value="<?php echo $info[0]['location'];?>">
                    <small class="form-text text-danger"><?php echo form_error('location');?></small>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
<?php $this->load->view('footer');?>
