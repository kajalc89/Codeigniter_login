<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarText">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
      <h4 class="text-primary"><u>SCHOOLS INFO</u></h4>
      </li>
    </ul>
    <span class="navbar">
    <a type="button" class="btn btn-primary btn-sm right" href="<?php echo base_url();?>schools/create">Add Schools data</a>
    </span>
    <span class="navbar">
    </span>
    <span class="navbar-text">
      <strong><a class="nav-link" href="<?php echo base_url();?>login/logout">Logout</a></strong>
    </span>
  </div>
</nav>