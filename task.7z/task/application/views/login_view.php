<?php $this->load->view('header');?>
<div class="row">
<div class="col-md-4">
</div>
<div class="col-md-4 pt-2">
    <div class="card">
        <div class="card-body">
      <?php  if (isset($error)){
        echo "<div class='alert alert-danger text-center' role='alert'>$error</div>";
        }
        ?>
        <?php if($this->session->flashdata('success')){ ?>        
            <div class="alert alert-success text-center" role="alert">
                <?=$this->session->flashdata('success');?>
            </div>
        <?php }  ?>

        <div class="text-center">
        <h3 class="text-primary">Login</h3>
        </div>
            <form action="<?php echo base_url();?>login/get_user" method="POST">
                <div class="form-group">
                    <label for="exampleInputEmail1"><strong>Email address</strong></label>
                    <input type="email" class="form-control" name="email" aria-describedby="emailHelp" placeholder="Enter email">
                    <small class="form-text text-danger"><?php echo form_error('email');?></small>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1"><strong>Passwaord</strong></label>
                    <input type="password" class="form-control"  name="password" placeholder="Password">
                    <small class="form-text text-danger"><?php echo form_error('password');?></small>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                <div class="text-right">
                <a href="<?php echo base_url('register');?>" class="text-center"><strong>Register a new Account</strong></a>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
<?php $this->load->view('footer');?>
