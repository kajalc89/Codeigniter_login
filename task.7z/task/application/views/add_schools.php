<?php $this->load->view('header');?>
<div class="row">
<div class="col-md-3">
</div>
<div class="col-md-6 pt-2">
    <div class="card">
        <div class="card-body">
  
        <?php if($this->session->flashdata('success')){ ?>        
            <div class="alert alert-success text-center" role="alert">
                <?=$this->session->flashdata('success');?>
            </div>
        <?php }  ?>

        <div class="text-center">
        <h3 class="text-primary"><strong>Add Details</strong></h3>
        </div>
            <form action="<?php echo base_url();?>schools/create" method="POST">
                <div class="form-group">
                    <label for="exampleInputEmail1"><strong>Name</strong></label>
                    <input type="text" class="form-control" name="name" aria-describedby="emailHelp" placeholder="Enter Name">
                    <small class="form-text text-danger"><?php echo form_error('name');?></small>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1"><strong>Location</strong></label>
                    <input type="text" class="form-control"  name="location" placeholder="Location">
                    <small class="form-text text-danger"><?php echo form_error('location');?></small>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
<?php $this->load->view('footer');?>
