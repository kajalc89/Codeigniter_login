<?php $this->load->view('header');?>
<?php $this->load->view('topbar');?>
<style>
 .right {
        float: right;
      } 
</style>
<div class="row">
<div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <!-- <div class="header-body text-center">
                <h4 class="text-primary"><u>SCHOOLS INFO</u></h4>
            </div>
            <div> <a type="button" class="btn btn-primary btn-sm right" href="<?php echo base_url();?>schools/create">Add Schools data</a>
            </div><br><br> -->
            <table id="dataTable1" class="table table-bordered pt-2">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Delete</th>
                    <th>Edit</th>
                </tr>
                </thead>
                <tbody>
                <?php $i=1; foreach($schoolsData as $row){ ?> 
                <tr>
                <td><?php echo $i++;?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['location'];?></td>
                    <td>
                        <a href="<?php echo base_url();?>schools/delete/<?php echo $row['id']; ?>" onclick ="return confirm('Are you sure to delete information')" class="btn btn-info btn-sm">
                            <span class="glyphicon glyphicon-trash"></span> Delete</a>
                    </td>
                    <td>
                        <a class="btn btn-warning btn-sm" href="<?php echo base_url();?>schools/edit/<?php echo $row['id']; ?>" class="text text-danger">Update</a>
                    </td>
                </tr>
                <?php } ?>

                </tbody>
            </table>
            
        <div>          
    </div>
    </div>
</div>
<?php $this->load->view('footer');?>
